
import {world_config as config} from '../../../public/world_config.js';
export const world_config = {
    url:config.base + "/fs/categories_scene_dir_ef3bfa76-330f-4bd8-87b7-4910cf8384ad/Category_ring_a",
	dirName:"categories_scene_dir_ef3bfa76-330f-4bd8-87b7-4910cf8384ad",
	dirPath:"./fs/categories_scene_dir_ef3bfa76-330f-4bd8-87b7-4910cf8384ad/Category_ring_a",
	dirUrl:"/fs/categories_scene_dir_ef3bfa76-330f-4bd8-87b7-4910cf8384ad/Category_ring_a",

}
        