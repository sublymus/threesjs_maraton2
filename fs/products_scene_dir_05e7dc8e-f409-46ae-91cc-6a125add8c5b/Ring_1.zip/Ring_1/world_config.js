
import {world_config as config} from '../../../public/world_config.js';
export const world_config = {
    url:config.base + "/fs/products_scene_dir_05e7dc8e-f409-46ae-91cc-6a125add8c5b/Ring_1",
	dirName:"products_scene_dir_05e7dc8e-f409-46ae-91cc-6a125add8c5b",
	dirPath:"./fs/products_scene_dir_05e7dc8e-f409-46ae-91cc-6a125add8c5b/Ring_1",
	dirUrl:"/fs/products_scene_dir_05e7dc8e-f409-46ae-91cc-6a125add8c5b/Ring_1",

}
        