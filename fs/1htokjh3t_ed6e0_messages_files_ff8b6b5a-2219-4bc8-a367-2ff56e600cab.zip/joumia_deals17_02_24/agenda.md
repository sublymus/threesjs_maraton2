# travaux commun
category 
min_max
vistes
recommendation link

- analyser la concurence
- cree les tables ( schema )
- cree les table ( DB )
- s'inpirer d'avito pour les paramertre

 FRONT_END 
 ```jsx
* PAGE_AUTH 
 

*PAGE_EDIT_MY_PROFILE
*PAGE_MY_PROFILE
*PAGE_OTHER_PROFILE

*PAGE_CREATE_PRODUCT 
PAGE_EDIT_PRODUCT
*PAGE_DETAIL_PRODUCT

PAGE_MAIN (  COMP_CATEGORY , COMP_FILTER , COM_PRODUCT ) 
NAV_FILTER 
text
category
prix



edit profile => page

notificaton  => page

messagerie => page

paramerte => page

mes annone , recommendation , visited , favorites , report 

SUB_PAGE_FAVORITES
SUB_PAGE_HISTORY ( my_annonce, recommendation(product / account {view , clik}) ,visited_product (15) , visited_account (15)   )


COMP_UDGRADE_TO_URGENT

SUB_PAGE_MESSAGE
COMP_MESSAGE
COMP_VOTE  ( 'the vote component will appreare inside the  product, when provider answered to you first message about product') ( revote_enable)


SUB_PAGE_PARAMETER  ( dark_mode ,  )
```

ROUTE = 'creation de route +  creation du test'

# ROUTE_AUTH
##  connexion
##  create user
##  deconnexion
  

# EDIT_PROFILE
##  me
##  edite_me
##  get_account 
##  get_account_from_ids

# ROUTE PRODUCT
##  create_product
##  get_groduct
##  update_product
##  delete_product
##  get_product_from_ids
##  filter_product 
<!-- valid_product -->
<!-- reject_product -->

# ROUTE CGATEGORY  
##  create_category
##  get_groduct
##  update_category
##  delete_category
##  cascad
##  get_category_from_ids
##  categories_filter


# ROUTE_MODERATEUR
##  create_moderator
##  get_groduct
##  update_moderator
##  delete_moderator
##  get_moderator_from_ids
##  change_moderator_key
    moderator_filter

# ROUTE_ACTION_USER
##  report
##  favorites
##  recommendation
link
vited
# File_manage
## ceateFiles()
## updateFiles()
## deleteFiles() // 2h
## on delete au moin 1
## access file
## use whatsapp 

# Account_VALIDATION
# auth_VALIDATION
# categories_VALIDATION
# favorites_VALIDATION
# Messenger_VALIDATION
# Moderator_VALIDATION
# Product_VALIDATION
#  rule:carateristiqueJson // 4h/////////////////////
# Recommendation_VALIDATION
# Reports_VALIDATION

# ROUTE_MESSENGER
## send message
## get messages
## get message
## get discussions
## delete discussion

<!-- ~ Pagination -->

~ miniature [1]

~ resize image ajouter le text

~ parse tout les json

ERROR

<!-- ~ ajouter etat au proctuct   ////  dans la caracteristique -->


ROUTE_MEDRATOR
RULES ACL

<!-- MIN_MAX (le strict minimux pour le produit)

filter product -  favorites

avatar
name
lacation

name product
price
etat =  [  ////  dans la caracteristique
    Etat neuf,
    tres bon etat,
    etat bon,
    etat etat
    satisfaisant,
    pour pieces
]
ceation date
et les 4 premiere caracteristiqyue -->

SSE integration ( trouver une pist )//1h

 <!-- ROUTE_VOTE // 2h -->


postgresql  


## PERMISSION 
# user
moderator
admin

ROUTE_TRANSATION

DOKER_IMAGE
TEST_VERCEL
HOSTINGER_PROD
TEST_PROD


5 / follow






















































annex 

- se mettre d'accord sur la forme des donner de chaque route ( entres / sorties)