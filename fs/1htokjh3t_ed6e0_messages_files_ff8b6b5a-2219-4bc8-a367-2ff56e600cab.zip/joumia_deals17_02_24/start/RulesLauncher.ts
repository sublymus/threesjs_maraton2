import '../app/Rules/FileList'
import '../app/Rules/caracteristiqueJSON'
import '../app/Rules/toJSON'
